import java.util.Locale;
import java.util.Scanner;

public class Ejercicio4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); // para escribir decimales con punto (25.5)

        System.out.print("Introduce un número: ");
        double numero = sc.nextDouble();

        try {
            double raiz = calcularRaiz(numero);
            System.out.println("La raíz cuadrada es: " + raiz);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        sc.close();
    }

    public static double calcularRaiz(double numero) throws IllegalArgumentException {
        if (numero < 0) {
            throw new IllegalArgumentException(
                    "No se puede calcular la raíz cuadrada de un número negativo.");
        }
        return Math.sqrt(numero);
    }
}
