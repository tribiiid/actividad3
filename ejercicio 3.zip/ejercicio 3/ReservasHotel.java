import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

public class ReservasHotel {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US);

        System.out.println("===== SISTEMA DE RESERVAS DE HOTEL =====");
        System.out.println();

        try {
            System.out.print("Nombre del cliente: ");
            String nombre = sc.nextLine();
            System.out.print("Número de habitación: ");
            int habitacion = sc.nextInt();
            System.out.print("Número de noches: ");
            int noches = sc.nextInt();
            System.out.print("Precio por noche: ");
            double precioNoche = sc.nextDouble();
            System.out.println();

            validarReserva(nombre, habitacion, noches, precioNoche);

            double total = calcularPrecio(noches, precioNoche);
            mostrarReserva(nombre, habitacion, noches, precioNoche, total);

        } catch (IllegalArgumentException e) {
            System.out.println("ERROR: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("ERROR: Has introducido un dato con formato incorrecto.");
        }

        sc.close();
    }

    // Validación de datos
    public static void validarReserva(String nombre, int habitacion, int noches,
            double precioNoche) throws IllegalArgumentException {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del cliente no puede estar vacío.");
        }
        if (habitacion <= 0) {
            throw new IllegalArgumentException("El número de habitación debe ser mayor que cero.");
        }
        if (noches <= 0) {
            throw new IllegalArgumentException("El número de noches debe ser mayor que cero.");
        }
        if (precioNoche <= 0) {
            throw new IllegalArgumentException("El precio por noche debe ser superior a cero.");
        }
    }

    // Cálculo del importe
    public static double calcularPrecio(int noches, double precioNoche) {
        return noches * precioNoche;
    }

    // Presentación de resultados
    public static void mostrarReserva(String nombre, int habitacion, int noches,
            double precioNoche, double total) {
        System.out.println("RESERVA REALIZADA CORRECTAMENTE");
        System.out.println();
        System.out.println("Cliente: " + nombre);
        System.out.println("Habitación: " + habitacion);
        System.out.println("Noches: " + noches);
        System.out.println("Precio por noche: " + precioNoche + " €");
        System.out.println("Precio total: " + total + " €");
    }
}
