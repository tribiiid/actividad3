// Única clase propia permitida: la excepción personalizada.
public class SaldoInsuficienteException extends Exception {

    private String titular;
    private double saldo;

    public SaldoInsuficienteException(String mensaje, String titular, double saldo) {
        super(mensaje);
        this.titular = titular;
        this.saldo = saldo;
    }

    public String getTitular() {
        return titular;
    }

    public double getSaldo() {
        return saldo;
    }
}
