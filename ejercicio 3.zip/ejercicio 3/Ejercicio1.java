import java.util.Scanner;

public class Ejercicio1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce el primer número: ");
        int dividendo = sc.nextInt();
        System.out.print("Introduce el segundo número: ");
        int divisor = sc.nextInt();

        try {
            int resultado = dividir(dividendo, divisor);
            System.out.println("Resultado: " + resultado);
        } catch (ArithmeticException e) {
            System.out.println("Error: No se puede dividir entre cero.");
        }

        System.out.println("El programa continúa su ejecución.");
        sc.close();
    }

    public static int dividir(int a, int b) {
        return a / b; // lanza ArithmeticException si b == 0
    }
}
