import java.util.Scanner;

public class Ejercicio3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce tu edad: ");
        int edad = sc.nextInt();

        try {
            comprobarEdad(edad);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        sc.close();
    }

    public static void comprobarEdad(int edad) {
        if (edad < 18) {
            throw new IllegalArgumentException("La edad debe ser igual o superior a 18 años.");
        }
        System.out.println("Acceso permitido.");
    }
}
