import java.util.Locale;
import java.util.Scanner;

public class Ejercicio5 {

    static String titular = "Juan";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US);

        double saldo = 500;

        System.out.println("Titular: " + titular);
        System.out.println("Saldo inicial: " + saldo + " €");
        System.out.println();
        System.out.print("Cantidad que desea retirar: ");
        double cantidad = sc.nextDouble();
        System.out.println();

        try {
            saldo = retirarDinero(saldo, cantidad);
            System.out.println("Retirada realizada correctamente.");
        } catch (SaldoInsuficienteException e) {
            System.out.println("Error: Saldo insuficiente para realizar la operación.");
        }

        System.out.println();
        System.out.println("Saldo actual: " + saldo + " €");
        sc.close();
    }

    public static double retirarDinero(double saldo, double cantidad)
            throws SaldoInsuficienteException {
        if (cantidad > saldo) {
            throw new SaldoInsuficienteException(
                    "Saldo insuficiente para realizar la operación.", titular, saldo);
        }
        return saldo - cantidad;
    }
}
