import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

public class Ejercicio6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US);

        boolean notaValida = false;

        while (!notaValida) {
            try {
                System.out.print("Introduce una nota: ");
                double nota = sc.nextDouble();
                validarNota(nota);
                notaValida = true; // si no hubo excepción, salimos del bucle
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (InputMismatchException e) {
                System.out.println("Error: Debes introducir un número.");
                sc.next(); // descarta el texto incorrecto
            }
            System.out.println();
        }

        sc.close();
    }

    public static void validarNota(double nota) throws IllegalArgumentException {
        if (nota < 0 || nota > 10) {
            throw new IllegalArgumentException("La nota debe estar comprendida entre 0 y 10.");
        }
        System.out.println("\nNota introducida correctamente: " + nota);
    }
}
